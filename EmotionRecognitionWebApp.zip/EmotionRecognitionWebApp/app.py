from flask import Flask, render_template, request
import numpy as np
import soundfile as sf  # Required for reading audio files like .wav
import librosa
import joblib

# Load the trained model
model = joblib.load('emotion_recognition_model.joblib')

# Flask app
app = Flask(__name__)

def extract_features(audio, sr=22050):
    # Extract MFCC features
    mfccs = librosa.feature.mfcc(y=audio, sr=sr, n_mfcc=13)
    mfccs_scaled = np.mean(mfccs.T, axis=0)
    return mfccs_scaled.reshape(1, -1)

@app.route('/', methods=['GET', 'POST'])
def index():
    emotion = None
    if request.method == 'POST':
        if 'audio-file' in request.files:
            file = request.files['audio-file']
            if file:
                # Read the audio file
                audio, sr = librosa.load(file, sr=22050)
                
                # Extract features
                features = extract_features(audio, sr)

                # Predict emotion
                prediction = model.predict(features)
                emotion = prediction[0]
    return render_template('index.html', emotion=emotion)

if __name__ == '__main__':
    app.run(debug=True)
